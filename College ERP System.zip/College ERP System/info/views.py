from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponseRedirect, JsonResponse
from .models import Dept, Class, Student, Attendance, Course, Teacher, Assign, AttendanceTotal, time_slots, \
    DAYS_OF_WEEK, AssignTime, AttendanceClass, StudentCourse, Marks, MarksClass
from django.urls import reverse
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from .timetable_generator import generate_timetable, get_timetable_for_class


# Create your views here.


@login_required
def index(request):
    if request.user.is_teacher:
        return render(request, 'info/t_homepage.html')
    if request.user.is_student:
        return render(request, 'info/homepage.html')
    return render(request, 'info/logout.html')


# Student login view with teacher restriction
def student_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                # Check if user is a teacher
                if hasattr(user, 'teacher'):
                    messages.error(request, "Teachers should use the staff login page.")
                    return redirect('staff_login')
                
                # Only allow student logins
                if hasattr(user, 'student'):
                    login(request, user)
                    return redirect('index')
                else:
                    messages.error(request, "You don't have student access.")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'info/login.html', {'form': form})


@login_required()
def attendance(request, stud_id):
    stud = Student.objects.get(USN=stud_id)
    ass_list = Assign.objects.filter(class_id_id=stud.class_id)
    att_list = []
    for ass in ass_list:
        try:
            a = AttendanceTotal.objects.get(student=stud, course=ass.course)
        except AttendanceTotal.DoesNotExist:
            a = AttendanceTotal(student=stud, course=ass.course)
            a.save()
        att_list.append(a)
    return render(request, 'info/attendance.html', {'att_list': att_list})


@login_required()
def attendance_detail(request, stud_id, course_id):
    stud = get_object_or_404(Student, USN=stud_id)
    cr = get_object_or_404(Course, id=course_id)
    att_list = Attendance.objects.filter(course=cr, student=stud).order_by('date')
    return render(request, 'info/att_detail.html', {'att_list': att_list, 'cr': cr})


# Teacher Views

@login_required
def t_clas(request, teacher_id, choice):
    teacher1 = get_object_or_404(Teacher, id=teacher_id)
    return render(request, 'info/t_clas.html', {'teacher1': teacher1, 'choice': choice})


@login_required()
def t_student(request, assign_id):
    ass = Assign.objects.get(id=assign_id)
    att_list = []
    for stud in ass.class_id.student_set.all():
        try:
            a = AttendanceTotal.objects.get(student=stud, course=ass.course)
        except AttendanceTotal.DoesNotExist:
            a = AttendanceTotal(student=stud, course=ass.course)
            a.save()
        att_list.append(a)
    return render(request, 'info/t_students.html', {'att_list': att_list})


@login_required()
def t_class_date(request, assign_id):
    now = timezone.now()
    ass = get_object_or_404(Assign, id=assign_id)
    att_list = ass.attendanceclass_set.filter(date__lte=now).order_by('-date')
    return render(request, 'info/t_class_date.html', {'att_list': att_list})


@login_required()
def cancel_class(request, ass_c_id):
    assc = get_object_or_404(AttendanceClass, id=ass_c_id)
    assc.status = 2
    assc.save()
    return HttpResponseRedirect(reverse('t_class_date', args=(assc.assign_id,)))


@login_required()
def t_attendance(request, ass_c_id):
    assc = get_object_or_404(AttendanceClass, id=ass_c_id)
    ass = assc.assign
    c = ass.class_id
    context = {
        'ass': ass,
        'c': c,
        'assc': assc,
    }
    return render(request, 'info/t_attendance.html', context)


@login_required()
def edit_att(request, ass_c_id):
    assc = get_object_or_404(AttendanceClass, id=ass_c_id)
    cr = assc.assign.course
    att_list = Attendance.objects.filter(attendanceclass=assc, course=cr)
    context = {
        'assc': assc,
        'att_list': att_list,
    }
    return render(request, 'info/t_edit_att.html', context)


@login_required()
def confirm(request, ass_c_id):
    assc = get_object_or_404(AttendanceClass, id=ass_c_id)
    ass = assc.assign
    cr = ass.course
    cl = ass.class_id
    for i, s in enumerate(cl.student_set.all()):
        status = request.POST[s.USN]
        if status == 'present':
            status = 'True'
        else:
            status = 'False'
        if assc.status == 1:
            try:
                a = Attendance.objects.get(course=cr, student=s, date=assc.date, attendanceclass=assc)
                a.status = status
                a.save()
            except Attendance.DoesNotExist:
                a = Attendance(course=cr, student=s, status=status, date=assc.date, attendanceclass=assc)
                a.save()
        else:
            a = Attendance(course=cr, student=s, status=status, date=assc.date, attendanceclass=assc)
            a.save()
            assc.status = 1
            assc.save()

    return HttpResponseRedirect(reverse('t_class_date', args=(ass.id,)))


@login_required()
def t_attendance_detail(request, stud_id, course_id):
    stud = get_object_or_404(Student, USN=stud_id)
    cr = get_object_or_404(Course, id=course_id)
    att_list = Attendance.objects.filter(course=cr, student=stud).order_by('date')
    return render(request, 'info/t_att_detail.html', {'att_list': att_list, 'cr': cr})


@login_required()
def change_att(request, att_id):
    a = get_object_or_404(Attendance, id=att_id)
    a.status = not a.status
    a.save()
    return HttpResponseRedirect(reverse('t_attendance_detail', args=(a.student.USN, a.course_id)))


@login_required()
def t_extra_class(request, assign_id):
    ass = get_object_or_404(Assign, id=assign_id)
    c = ass.class_id
    context = {
        'ass': ass,
        'c': c,
    }
    return render(request, 'info/t_extra_class.html', context)


@login_required()
def e_confirm(request, assign_id):
    ass = get_object_or_404(Assign, id=assign_id)
    cr = ass.course
    cl = ass.class_id
    assc = ass.attendanceclass_set.create(status=1, date=request.POST['date'])
    assc.save()

    for i, s in enumerate(cl.student_set.all()):
        status = request.POST[s.USN]
        if status == 'present':
            status = 'True'
        else:
            status = 'False'
        date = request.POST['date']
        a = Attendance(course=cr, student=s, status=status, date=date, attendanceclass=assc)
        a.save()

    return HttpResponseRedirect(reverse('t_clas', args=(ass.teacher_id, 1)))


@login_required()
def t_report(request, assign_id):
    ass = get_object_or_404(Assign, id=assign_id)
    sc_list = []
    for stud in ass.class_id.student_set.all():
        a = StudentCourse.objects.get(student=stud, course=ass.course)
        sc_list.append(a)
    return render(request, 'info/t_report.html', {'sc_list': sc_list})


@login_required()
def timetable(request, class_id):
    asst = AssignTime.objects.filter(assign__class_id=class_id)
    matrix = [['' for i in range(9)] for j in range(6)]

    # Define which slots are actual teaching periods (not breaks)
    teaching_slots = [0, 1, 3, 4, 6, 7]  # Indices of time_slots that are not breaks
    
    # Map table column indices to teaching slot indices
    column_to_slot = {
        1: 0,  # 9:00 - 10:00
        2: 1,  # 10:00 - 11:00
        4: 3,  # 11:15 - 12:15
        5: 4,  # 12:15 - 1:15
        7: 6,  # 2:00 - 3:00
        8: 7,  # 3:00 - 4:00
    }

    for i, d in enumerate(DAYS_OF_WEEK):
        for j in range(9):
            if j == 0:
                matrix[i][0] = d[0]
                continue
            if j == 3 or j == 6:  # Break periods
                continue
            
            # Get the correct slot index from our mapping
            slot_idx = column_to_slot.get(j)
            if slot_idx is not None:
                try:
                    a = asst.get(period=time_slots[slot_idx][0], day=d[0])
                    matrix[i][j] = a.assign.course_id
                except AssignTime.DoesNotExist:
                    pass

    context = {'matrix': matrix}
    return render(request, 'info/timetable.html', context)


@login_required()
def t_timetable(request, teacher_id):
    asst = AssignTime.objects.filter(assign__teacher_id=teacher_id)
    class_matrix = [[True for i in range(9)] for j in range(6)]
    
    # Define which slots are actual teaching periods (not breaks)
    teaching_slots = [0, 1, 3, 4, 6, 7]  # Indices of time_slots that are not breaks
    
    # Map table column indices to teaching slot indices
    column_to_slot = {
        1: 0,  # 9:00 - 10:00
        2: 1,  # 10:00 - 11:00
        4: 3,  # 11:15 - 12:15
        5: 4,  # 12:15 - 1:15
        7: 6,  # 2:00 - 3:00
        8: 7,  # 3:00 - 4:00
    }
    
    for i, d in enumerate(DAYS_OF_WEEK):
        for j in range(9):
            if j == 0:
                class_matrix[i][0] = d[0]
                continue
            if j == 3 or j == 6:  # Break periods
                continue
            
            # Get the correct slot index from our mapping
            slot_idx = column_to_slot.get(j)
            if slot_idx is not None:
                try:
                    a = asst.get(period=time_slots[slot_idx][0], day=d[0])
                    class_matrix[i][j] = a
                except AssignTime.DoesNotExist:
                    pass

    context = {
        'class_matrix': class_matrix,
    }
    return render(request, 'info/t_timetable.html', context)


@login_required()
def free_teachers(request, asst_id):
    asst = get_object_or_404(AssignTime, id=asst_id)
    ft_list = []
    t_list = Teacher.objects.filter(assign__class_id__id=asst.assign.class_id_id)
    for t in t_list:
        at_list = AssignTime.objects.filter(assign__teacher=t)
        if not any([True if at.period == asst.period and at.day == asst.day else False for at in at_list]):
            ft_list.append(t)

    return render(request, 'info/free_teachers.html', {'ft_list': ft_list})


# student marks


@login_required()
def marks_list(request, stud_id):
    stud = Student.objects.get(USN=stud_id, )
    ass_list = Assign.objects.filter(class_id_id=stud.class_id)
    sc_list = []
    for ass in ass_list:
        try:
            sc = StudentCourse.objects.get(student=stud, course=ass.course)
        except StudentCourse.DoesNotExist:
            sc = StudentCourse(student=stud, course=ass.course)
            sc.save()
            sc.marks_set.create(type='I', name='Internal test 1')
            sc.marks_set.create(type='I', name='Internal test 2')
            sc.marks_set.create(type='I', name='Internal test 3')
            sc.marks_set.create(type='E', name='Event 1')
            sc.marks_set.create(type='E', name='Event 2')
            sc.marks_set.create(type='S', name='Semester End Exam')
        sc_list.append(sc)

    return render(request, 'info/marks_list.html', {'sc_list': sc_list})


# teacher marks


@login_required()
def t_marks_list(request, assign_id):
    ass = get_object_or_404(Assign, id=assign_id)
    m_list = MarksClass.objects.filter(assign=ass)
    return render(request, 'info/t_marks_list.html', {'m_list': m_list})


@login_required()
def t_marks_entry(request, marks_c_id):
    mc = get_object_or_404(MarksClass, id=marks_c_id)
    ass = mc.assign
    c = ass.class_id
    context = {
        'ass': ass,
        'c': c,
        'mc': mc,
    }
    return render(request, 'info/t_marks_entry.html', context)


@login_required()
def marks_confirm(request, marks_c_id):
    mc = get_object_or_404(MarksClass, id=marks_c_id)
    ass = mc.assign
    cr = ass.course
    cl = ass.class_id
    for s in cl.student_set.all():
        mark = request.POST[s.USN]
        sc = StudentCourse.objects.get(course=cr, student=s)
        m = sc.marks_set.get(name=mc.name)
        m.marks1 = mark
        m.save()
    mc.status = True
    mc.save()

    return HttpResponseRedirect(reverse('t_marks_list', args=(ass.id,)))


@login_required()
def edit_marks(request, marks_c_id):
    mc = get_object_or_404(MarksClass, id=marks_c_id)
    cr = mc.assign.course
    stud_list = mc.assign.class_id.student_set.all()
    m_list = []
    for stud in stud_list:
        sc = StudentCourse.objects.get(course=cr, student=stud)
        m = sc.marks_set.get(name=mc.name)
        m_list.append(m)
    context = {
        'mc': mc,
        'm_list': m_list,
    }
    return render(request, 'info/edit_marks.html', context)


@login_required()
def student_marks(request, assign_id):
    ass = Assign.objects.get(id=assign_id)
    sc_list = StudentCourse.objects.filter(student__in=ass.class_id.student_set.all(), course=ass.course)
    return render(request, 'info/t_student_marks.html', {'sc_list': sc_list})


# Staff login view
def staff_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                # Check if user is a student
                if hasattr(user, 'student'):
                    messages.error(request, "Students should use the student login page.")
                    return redirect('login')
                
                # Only allow teacher logins
                if hasattr(user, 'teacher'):
                    login(request, user)
                    return redirect('staff_home')
                else:
                    messages.error(request, "You don't have staff access.")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = AuthenticationForm()
    return render(request, 'info/staff_login.html', {'form': form})


# Staff home dashboard view
@login_required
def staff_home(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    assignments = Assign.objects.filter(teacher=teacher)
    
    # Get upcoming classes for the teacher
    upcoming_classes = AssignTime.objects.filter(assign__in=assignments).order_by('day', 'period')
    
    context = {
        'teacher': teacher,
        'assignments': assignments,
        'upcoming_classes': upcoming_classes,
    }
    
    return render(request, 'info/staff_homepage.html', context)


# Staff attendance management view
@login_required
def staff_attendance(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    assignments = Assign.objects.filter(teacher=teacher)
    
    context = {
        'teacher': teacher,
        'assignments': assignments,
    }
    
    return render(request, 'info/staff_attendance.html', context)


# Staff marks management view
@login_required
def staff_marks(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    assignments = Assign.objects.filter(teacher=teacher)
    
    context = {
        'teacher': teacher,
        'assignments': assignments,
    }
    
    return render(request, 'info/staff_marks.html', context)


# Staff courses management view
@login_required
def staff_courses(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    assignments = Assign.objects.filter(teacher=teacher)
    courses = Course.objects.filter(assign__in=assignments).distinct()
    
    context = {
        'teacher': teacher,
        'courses': courses,
    }
    
    return render(request, 'info/staff_courses.html', context)


# Staff timetable management view
@login_required
def staff_timetable(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    asst = AssignTime.objects.filter(assign__teacher=teacher)
    
    context = {
        'teacher': teacher,
        'asst': asst,
    }
    
    return render(request, 'info/staff_timetable.html', context)


# Staff students management view
@login_required
def staff_students(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    assignments = Assign.objects.filter(teacher=teacher)
    
    # Get all classes taught by the teacher
    classes = Class.objects.filter(assign__in=assignments).distinct()
    
    # Get all students in those classes
    students = Student.objects.filter(class_id__in=classes).distinct()
    
    context = {
        'teacher': teacher,
        'students': students,
        'classes': classes,
    }
    
    return render(request, 'info/staff_students.html', context)


# Staff reports view
@login_required
def staff_reports(request):
    if not request.user.is_teacher:
        return redirect('staff_login')
    
    teacher = request.user.teacher
    assignments = Assign.objects.filter(teacher=teacher)
    
    context = {
        'teacher': teacher,
        'assignments': assignments,
    }
    
    return render(request, 'info/staff_reports.html', context)


# Automatic Timetable Generation views
@login_required
def auto_timetable(request):
    """View for generating automatic timetable."""
    if not request.user.is_teacher:
        return redirect('login')
    
    teachers = Teacher.objects.all()
    classes = Class.objects.all()
    
    context = {
        'teachers': teachers,
        'classes': classes,
    }
    
    return render(request, 'info/auto_timetable.html', context)


@login_required
def generate_auto_timetable(request):
    """Generate automatic timetable and redirect to results."""
    if not request.user.is_teacher:
        return redirect('login')
    
    # Check prerequisites before even trying
    teachers_count = Teacher.objects.count()
    classes_count = Class.objects.count()
    courses_count = Course.objects.count()
    assignments_count = Assign.objects.count()
    
    debug_info = f"Teachers: {teachers_count}, Classes: {classes_count}, Courses: {courses_count}, Assignments: {assignments_count}"
    
    # Validate required data exists
    if teachers_count == 0:
        messages.error(request, f"No teachers found in the database. Please add teachers first. {debug_info}")
        return redirect('auto_timetable')
    
    if classes_count == 0:
        messages.error(request, f"No classes found in the database. Please add classes first. {debug_info}")
        return redirect('auto_timetable')
    
    if courses_count == 0:
        messages.error(request, f"No courses found in the database. Please add courses first. {debug_info}")
        return redirect('auto_timetable')
    
    if assignments_count == 0:
        messages.error(request, f"No course assignments found in the database. Please create teacher-course-class assignments first. {debug_info}")
        return redirect('auto_timetable')
    
    if request.method == 'POST' or request.method == 'GET':  # Allow GET for direct access
        try:
            # Clear existing timetable data first to ensure clean generation
            AssignTime.objects.all().delete()
            
            result = generate_timetable()
            slots_allocated = result['slots_allocated']
            
            if slots_allocated == 0:
                messages.warning(request, f"Timetable was generated but no slots were allocated. This is unusual. {debug_info}")
            else:
                messages.success(request, f"Timetable generated successfully! {slots_allocated} slots allocated. {debug_info}")
            
            return redirect('view_generated_timetable')
        except Exception as e:
            import traceback
            error_message = str(e)
            trace = traceback.format_exc()
            messages.error(request, f"Error generating timetable: {error_message}. Debug: {debug_info}. Trace: {trace[:200]}...")
            return redirect('auto_timetable')
    
    return redirect('auto_timetable')


@login_required
def view_generated_timetable(request):
    """View the generated timetable."""
    if not request.user.is_teacher:
        return redirect('login')
    
    class_id = request.GET.get('class_id')
    teacher_id = request.GET.get('teacher_id')
    
    classes = Class.objects.all()
    teachers = Teacher.objects.all()
    
    # Map table column indices to teaching slot indices
    column_to_slot = {
        1: 0,  # 9:00 - 10:00
        2: 1,  # 10:00 - 11:00
        4: 3,  # 11:15 - 12:15
        5: 4,  # 12:15 - 1:15
        7: 6,  # 2:00 - 3:00
        8: 7,  # 3:00 - 4:00
    }
    
    if class_id:
        selected_class = get_object_or_404(Class, id=class_id)
        # Get class timetable
        assign_times = AssignTime.objects.filter(assign__class_id=selected_class.id).order_by('day', 'period')
        
        matrix = [['' for i in range(9)] for j in range(6)]
        
        for i, d in enumerate(DAYS_OF_WEEK):
            for j in range(9):
                if j == 0:
                    matrix[i][0] = d[0]
                    continue
                if j == 3 or j == 6:  # Break periods
                    continue
                
                # Get the correct slot index from our mapping
                slot_idx = column_to_slot.get(j)
                if slot_idx is not None:
                    try:
                        a = assign_times.get(period=time_slots[slot_idx][0], day=d[0])
                        matrix[i][j] = a.assign.course_id
                    except AssignTime.DoesNotExist:
                        pass
        
        context = {
            'matrix': matrix,
            'classes': classes,
            'teachers': teachers,
            'selected_class': selected_class,
            'view_type': 'class'
        }
    
    elif teacher_id:
        selected_teacher = get_object_or_404(Teacher, id=teacher_id)
        # Get teacher timetable
        assign_times = AssignTime.objects.filter(assign__teacher_id=selected_teacher.id).order_by('day', 'period')
        
        class_matrix = [[True for i in range(9)] for j in range(6)]
        for i, d in enumerate(DAYS_OF_WEEK):
            for j in range(9):
                if j == 0:
                    class_matrix[i][0] = d[0]
                    continue
                if j == 3 or j == 6:  # Break periods
                    continue
                
                # Get the correct slot index from our mapping
                slot_idx = column_to_slot.get(j)
                if slot_idx is not None:
                    try:
                        a = assign_times.get(period=time_slots[slot_idx][0], day=d[0])
                        class_matrix[i][j] = a
                    except AssignTime.DoesNotExist:
                        pass
        
        context = {
            'class_matrix': class_matrix,
            'classes': classes,
            'teachers': teachers,
            'selected_teacher': selected_teacher,
            'view_type': 'teacher'
        }
    
    else:
        context = {
            'classes': classes,
            'teachers': teachers,
            'view_type': 'none'
        }
    
    return render(request, 'info/view_generated_timetable.html', context)
