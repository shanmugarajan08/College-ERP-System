from django import template

register = template.Library()

@register.filter
def index(lst, i):
    """Return the element at index i of the list."""
    try:
        return lst[int(i)]
    except (IndexError, TypeError, ValueError):
        return None

@register.filter
def get_teacher(course):
    """Return the teacher name for a course."""
    try:
        return course.teacher.name
    except (AttributeError, TypeError):
        return "" 